# Platform ALZ Implementation

`implementations/platform-lz` is a workspace catalog, not a deployable Terraform root.

Each platform lifecycle boundary is deployed from an individual root under `workspaces/` and mapped to its own HCP Terraform workspace. This matches the IaC delivery strategy: ownership, state, approval, drift, recovery, and blast radius stay scoped to the platform domain being changed.

The roots still reuse the common pattern modules under `../../patterns`. The AVM/HCP improvements are fitted into those patterns, so the separated workspaces compose the same reusable implementation instead of copying standalone AVM stacks.

## Workspace Roots

```text
workspaces/platform-governance
workspaces/platform-authorization        # Entra RBAC groups + MG-scope role assignments
workspaces/platform-workload-identity    # federated (OIDC) app registrations + SPs
workspaces/platform-privileged-access    # PIM eligible assignments + break-glass alert
workspaces/platform-subscriptions
workspaces/platform-policy
workspaces/platform-management
workspaces/platform-connectivity
workspaces/platform-identity-security
workspaces/platform-hybrid-connectivity
workspaces/platform-palo-alto
workspaces/platform-directory-services
workspaces/platform-cloudflare-connectors
workspaces/platform-workload-spoke
workspaces/platform-network-peering
workspaces/platform-cloudflare-edge
```

Identity & RBAC (design-doc "Identity & RBAC Design v2.0"): the three identity
workspaces above cover the IaC-appropriate parts of all 10 phases;
`IDENTITY-RBAC-IAC-BOUNDARY.md` maps every step to IaC or a documented manual
control. These supersede `compeer-alz-avm/stacks/{07-identity-groups,
08-workload-identity,03-privileged-access}` (now deprecated).

Each root has its own `terraform.tfvars.example` and should be attached to a distinct HCP Terraform workspace working directory.

For opt-in backfill of existing subscriptions after the DINE rollout, see
[platform-policy/remediation-example.tf](workspaces/platform-policy/remediation-example.tf).
It reuses existing assignments and keeps targets empty until explicit approval;
the comments explain the related implementation changes and rollout checks.

## Dependency Model

Dependent roots consume approved outputs with the HCP Terraform `tfe_outputs` data source, or through explicit IDs supplied as workspace variables. Do not use broad remote-state access for normal dependencies.

Examples:

- `platform-connectivity` can read `platform-management.log_analytics_workspace_id` for diagnostics.
- `platform-policy` can read `platform-governance.management_group_ids` for policy definitions and assignments.
- `platform-identity-security` can read `platform-management.log_analytics_workspace_id` and `platform-connectivity.private_dns_zone_ids`.
- `platform-hybrid-connectivity` can read `platform-connectivity.subnet_ids["GatewaySubnet"]`.
- `platform-directory-services` can read `platform-connectivity.subnet_ids` and `platform-management.log_analytics_workspace_id`.
- `platform-cloudflare-connectors` can read the connector subnet from `platform-connectivity` and monitoring outputs from `platform-management`.
- workload spoke roots can read hub VNet, private DNS, and Log Analytics outputs.
- `network-peering` reads connectivity and workload-spoke outputs to create the peering and DNS links.
- `platform-cloudflare-edge` owns Cloudflare account resources only; Azure connector VMs stay in `platform-cloudflare-connectors`.
- `platform-authorization` reads nothing; it is consumed by `platform-subscription-onboarding`, `platform-workload-spoke`, and `platform-privileged-access` (`group_object_ids`).
- `platform-privileged-access` reads `platform-management.log_analytics_workspace_id` (break-glass alert) and `platform-authorization.group_object_ids` (PIM principals).
- `platform-workload-identity` reads nothing; `platform-iac-foundation` (if used) consumes its `application_client_ids` to wire HCP workspace variables.

Provider subscription context remains an explicit workspace variable or HCP dynamic credential setting. Terraform should not configure an Azure provider from a producer workspace output inside the same run.

See `WORKSPACES.md` for the deployment order and output contracts, and
`PATTERN-REFERENCE.md` for what each pattern deploys and why — including the
full live-vs-designed Azure Policy table cross-referenced against the ALZ
design doc and the Identity & RBAC doc.

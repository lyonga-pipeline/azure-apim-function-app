# Platform Workspace Catalog

## Execution model

These roots are **VCS-driven HCP Terraform workspaces** — one HCP workspace per
directory here, connected to `main` with the workspace's working directory set to
that path (runbook §1.1). There is intentionally **no `cloud {}` / `backend`
block** in the code: state, execution, and the org/project binding are configured
in HCP, and plan/apply are authoritative there.

Do not run `terraform apply` locally against these roots (runbook §16). Local
`terraform init -backend=false` + `validate` + `test` is the offline check; the
CI pipeline (`.azuredevops/alz-validate.yml`) runs it on every PR.

Auth is HCP dynamic credentials / workload-identity federation to Azure — no
long-lived client secrets. Deployment identities are split at least by
governance/policy, connectivity, identity, and management.

### `tenant_id` / `subscription_id` (the one gotcha)

The `azurerm` provider block passes `subscription_id = var.subscription_id` and
`tenant_id = var.tenant_id`, so **both must exist as HCP variables of category
`Terraform`** — not `env`. An `env`-category variable named `tenant_id` becomes
an OS env var and does **not** satisfy `var.tenant_id`; that produces the
`No value for required variable "tenant_id"` run error. (`ARM_TENANT_ID` /
`ARM_SUBSCRIPTION_ID` are env vars for the provider's own auth and are a
different thing — don't rely on them to feed the Terraform variables.)

| Variable | Where to set it | Why |
|---|---|---|
| `tenant_id` | shared **variable set** (category: Terraform, key `tenant_id`) | constant across the tenant |
| `subscription_id` (or `execution_subscription_id`, `hub_/spoke_subscription_id`) | the **workspace's** own Terraform variables | differs per landing zone |

Neither is set in `terraform.tfvars` — those files carry only the workspace's
resource configuration. Avoid also defining these at workspace level when the
variable set already provides them (precedence gets confusing); override at the
workspace only for a genuine exception.

## Deployment Order

1. `platform-governance` -> HCP workspace `platform-governance` (MG hierarchy + `policy_baseline` in Audit)
2. `platform-authorization` -> HCP workspace `platform-authorization` (Entra RBAC groups + MG-scope role assignments + custom roles; needs directory write + User Access Administrator at `compeer-enterprise-mg`)
3. `platform-workload-identity` -> HCP workspace `platform-workload-identity` (federated app registrations + SPs + FICs; any time after governance)
4. `platform-privileged-access` -> HCP workspace `platform-privileged-access` (PIM eligible assignments + break-glass alert; needs steps 2 and 7)
5. `platform-subscription-onboarding` -> HCP workspace `platform-subscription-onboarding` (place CSP-created subscriptions into their MG + baseline RBAC; consumes step 2 `group_object_ids`)
   - `platform-subscriptions` is **NOT DEPLOYED** — retained for a future EA/MCA billing model only.
6. `platform-policy` -> HCP workspace `platform-policy` (exemptions, RG-scope assignments, DeployIfNotExists remediation, private-only guardrail; needs the Log Analytics workspace from step 7)
7. `platform-management` -> HCP workspace `platform-management`
8. `platform-connectivity` -> HCP workspace `platform-connectivity`
9. `platform-identity-security` -> HCP workspace `platform-identity-security`
10. `platform-hybrid-connectivity` -> HCP workspace `platform-hybrid-connectivity`
11. `platform-palo-alto` -> HCP workspace `platform-palo-alto`
12. `platform-directory-services` -> HCP workspace `platform-directory-services`
13. `platform-cloudflare-connectors` -> HCP workspace `platform-cloudflare-connectors`
14. `platform-workload-spoke` -> template root for one workspace per workload/environment, such as `workload-spoke-internal-apps-prod`
15. `platform-network-peering` -> template root for one workspace per peering set, after the hub and spoke workspaces have applied
16. `platform-cloudflare-edge` -> optional Cloudflare-owned edge workspace

`platform-policy` step 6 can also run late (after step 7) — its DeployIfNotExists
remediation reads `log_analytics_workspace_id` from `platform-management`.
Steps 8 through 13 can run in parallel where their upstream outputs are already available and the operational approvals are complete.

**Retired:** `platform-shared-services` (was step 14) — its whole premise
(a dedicated VNet spoke, peered to the hub, for domain-controller-adjacent
"shared services") was corrected in design review: those services belong
directly in the hub, not a separate peered VNet. See
`PATTERN-REFERENCE.md`'s "Deployment order" section for the full writeup.
Deleted outright — it was never populated in the real tfvars.

The identity / RBAC IaC boundary (what is codified vs. deliberately manual across
all 10 design-doc phases) is documented in `IDENTITY-RBAC-IAC-BOUNDARY.md`.

## Output Contracts

`platform-governance` publishes:

- `management_group_ids`
- `custom_role_definition_ids`
- `role_assignment_ids`

`platform-authorization` publishes:

- `group_object_ids` (keyed by `rbac_groups` key — consumed by
  `platform-subscription-onboarding`, `platform-workload-spoke`,
  `platform-privileged-access`)
- `group_display_names`
- `custom_role_definition_ids`
- `role_assignment_ids`
- `operational_contracts`, `manual_control_keys`

`platform-workload-identity` publishes:

- `application_client_ids` (→ HCP `TFC_AZURE_RUN_CLIENT_ID` per workspace)
- `service_principal_object_ids`
- `federated_credential_ids`
- `role_assignment_ids`
- `operational_contracts`, `manual_control_keys`

`platform-privileged-access` publishes:

- `pim_eligible_role_assignment_ids`
- `break_glass_alert_id`
- `operational_contracts`, `manual_control_keys`

`platform-subscription-onboarding` publishes:

- `subscription_placement_ids`
- `onboarded_subscription_ids`
- `onboarded_subscription_resource_ids`
- `baseline_role_assignment_ids`
- `legacy_policy_removal_ids` (legacy subscription/RG-scope policy assignments imported and pending removal — see the pattern's README)

`platform-policy` publishes:

- `custom_policy_definition_ids`
- `custom_policy_set_definition_ids`
- `management_group_policy_assignment_ids`
- `subscription_policy_assignment_ids`
- `resource_group_policy_assignment_ids`
- `policy_exemption_ids`
- `remediation_assignment_ids`
- `remediation_assignment_principal_ids`

`platform-management` publishes:

- `log_analytics_workspace_id`
- `log_analytics_workspace_ids` (map keyed by environment — Platform_Output_Contracts_IAC-10)
- `log_analytics_workspace_guid`
- `log_analytics_workspace_guids` (map keyed by environment)
- `action_group_id`
- `action_group_ids` (map — Platform_Output_Contracts_IAC-10)
- `diagnostic_profile` (canonical default diagnostic-settings profile — Platform_Output_Contracts_IAC-10)
- `defender_plan_ids`
- `contract_version`
- `platform_storage_account_ids`
- `data_collection_endpoint_ids`
- `data_collection_rule_ids`
- `data_collection_rule_association_ids`
- `sentinel_onboarding_id`

`platform-connectivity` publishes:

- `hub_virtual_network_id`
- `hub_virtual_network_name`
- `subnet_ids`
- `private_dns_zone_ids`
- `private_dns_zone_names`
- `private_dns_zone_resource_group_names`
- `bastion_id`
- `network_watcher_flow_logs`

`platform-identity-security` publishes:

- `platform_identity_principal_ids`
- `key_vault_id`
- `key_vault_name`
- `key_vault_uri`
  - The platform Key Vault private endpoint is intentionally not published here:
    the refined placement keeps platform private endpoints in the connectivity
    subscription because they attach to the hub VNet private endpoint subnet.
  - The pattern module name is historical: `terraform-azurerm-compeer-platform-identity`
    is consumed by the `platform-identity-security` workspace and deploys the
    security-subscription Key Vault/managed-identity boundary, not the domain
    controller estate.

`platform-hybrid-connectivity` publishes:

- `expressroute_circuit_ids`
- `expressroute_gateway_id`
- `expressroute_connection_ids`
- `expressroute_posture`
- `vpn_gateway_id`
- `local_network_gateway_ids`
- `vpn_connection_ids`
- `vpn_posture`

`platform-palo-alto` publishes:

- `marketplace_agreement_id`
- `bootstrap_storage_account_id`
- `bootstrap_storage_share_ids`
- `public_ip_ids`
- `network_interface_ids`
- `load_balancer_ids`
- `virtual_machine_ids`
- `virtual_machine_identity_principal_ids`
- `recovery_services_vault_ids`
- `backup_policy_vm_ids`
- `firewall_backup_protected_vm_ids`

`platform-directory-services` publishes:

- `domain_controller_ids`
- `domain_controller_private_ips`
- `network_interface_ids`
- `data_disk_ids`
- `data_disk_attachment_ids`
- `domain_join_extension_ids`
- `operational_contracts`

`platform-cloudflare-connectors` publishes:

- `connector_vm_ids`
- `connector_vm_private_ips`
- `network_interface_ids`
- `operational_contracts`

`platform-cloudflare-edge` publishes:

- `zone_ids`
- `record_ids`
- `ruleset_ids`
- `tunnel_ids`
- `tunnel_cnames`
- `tunnel_dns_record_ids`
- `access_application_ids`
- `access_policy_ids`

Workload spoke roots publish:

- `spoke_virtual_network_id`
- `subnet_ids`
- `private_endpoint_subnet_id`
- `workload_identity_principal_id`
- `workload_key_vault_id`

## Dependency Rules

- Use `tfe_outputs` for declared output consumption.
- Use explicit workspace variables when an ID is supplied by an external owner or when it configures the provider subscription context.
- Do not use `terraform_remote_state` unless formally approved.
- Do not let two workspaces own the same Azure resource.
- Keep optional or cost-bearing resources behind the existing `enabled` flags or empty maps until approved.

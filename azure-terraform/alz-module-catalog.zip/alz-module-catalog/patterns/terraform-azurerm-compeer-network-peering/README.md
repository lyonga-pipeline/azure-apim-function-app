# Network Peering HCP Adapter

## Overview

**What this deploys:** the cross-subscription VNet peering + Private DNS
zone links between one hub and one workload spoke. This legacy HCP-output
adapter delegates Azure resources to the pure hub-spoke-peering pattern.
The spoke blueprint calls that same pure pattern without HCP dependencies.

| Resource | Purpose |
|---|---|
| `azurerm_virtual_network_peering` (module, aliased `hub`/`spoke` providers) | The two-way peering |
| `azurerm_private_dns_zone_virtual_network_link` (module) | Links the hub's shared Private DNS zones to the spoke VNet |
| `terraform_data.resolved_input_validation` | See below |

**`terraform_data.resolved_input_validation` — why resolution is checked
before use:** this pattern can source hub/spoke identifiers either from
explicit variables or from `tfe_outputs` (another workspace's state). A
stale or unreadable `tfe_outputs` source would otherwise plan a peering
against `null` resource IDs; the contract fails the plan cleanly instead.
See `tests/contracts.tftest.hcl`.

---

This root owns the cross-subscription network attachment between one hub VNet and one workload spoke VNet. It creates both Azure peering resources and links shared Private DNS zones to the spoke VNet.

Use this adapter in a dedicated HCP workspace when a separately privileged
central attachment state is appropriate. A separate workspace is not required
merely because there is a separate peering ticket. For platform-owned spoke
provisioning the new blueprint composes the pure pattern directly. Do not also
apply this adapter for a spoke with manage_hub_attachment=true, or enable legacy
hub_connection for the same resource pair. Each peering has exactly one state.

The azurerm.dns alias now targets the actual existing DNS subscription. In the
platform-network-peering root, set optional private_dns_subscription_id when
DNS is outside the hub subscription; null retains the previous hub default.
Direct callers of this adapter must supply hub, spoke and dns provider aliases.
Set each zone's actual resource_group_name or the correct shared default.
The adapter now reads nonsensitive_values only; sensitive .values never fill
missing public contracts. Azure names remain unchanged unless explicitly
overridden. Moved blocks preserve existing internal peering/link addresses;
review an actual plan for moves, not replacements, before upgrading a live state.

## Inputs

By default this root consumes upstream HCP Terraform workspace outputs with `tfe_outputs`. Set these as Terraform variables in the peering workspace:

- `tenant_id` only when not supplied by the HCP Azure dynamic credential set. Leave it unset for normal HCP dynamic credential runs.
- `hub_subscription_id`
- `spoke_subscription_id`
- `tfe_organization`, defaults to `lyonga-org`
- `platform_connectivity_workspace_name`, defaults to `platform-connectivity`
- `workload_spoke_workspace_name`, defaults to `workload-spoke`
- `peering_name_prefix`, defaults to `online-banking-np1`

Do not rename `terraform.tfvars.example` to `terraform.tfvars` in this root. HCP Terraform automatically loads checked-in `terraform.tfvars` files, and placeholder values can override missing workspace variables.

The `platform-connectivity` workspace must publish:

- `hub_resource_group_name`
- `hub_virtual_network_name`
- `hub_virtual_network_id`
- `resource_group_name`

The `workload-spoke` workspace must publish:

- `spoke_resource_group_name`
- `spoke_virtual_network_name`
- `spoke_virtual_network_id`

This pattern is preferred over duplicating IDs manually in every consumer workspace. It keeps the platform and workload states isolated while exposing only declared outputs through the HCP Terraform API.

## Why `TFE_TOKEN` is used

The peering workspace uses the `tfe_outputs` data source to read declared outputs from the `platform-connectivity` and `workload-spoke` workspaces. HCP Terraform can run the Azure providers with dynamic Azure credentials, but the TFE provider still needs an HCP Terraform API credential when it reads outputs from other workspaces.

Set a sensitive environment variable named `TFE_TOKEN` in the peering workspace when the run environment does not already provide a token with enough HCP Terraform permissions. Use a team token or service account token with the narrowest practical read access to the producer workspaces.

This token is not an Azure credential and does not grant access to Azure resources. It is only used by the TFE provider to read HCP Terraform metadata, specifically the declared outputs that the peering root needs.

Do not enable broad remote state sharing for this pattern. Remote state sharing is mainly for `terraform_remote_state`, which reads from state snapshots. `tfe_outputs` is preferred because it reads declared outputs through the HCP Terraform API instead of granting backend-level state access.

Manual variables remain as an override/fallback. Set `use_tfe_outputs = false` and provide the values directly if output sharing is not available.

Manual fallback example:

```hcl
use_tfe_outputs = false

hub_resource_group_name  = "<platform-connectivity output: hub_resource_group_name>"
hub_virtual_network_name = "<platform-connectivity output: hub_virtual_network_name>"
hub_virtual_network_id   = "<platform-connectivity output: hub_virtual_network_id>"

spoke_resource_group_name  = "<workload-spoke output: spoke_resource_group_name>"
spoke_virtual_network_name = "<workload-spoke output: spoke_virtual_network_name>"
spoke_virtual_network_id   = "<workload-spoke output: spoke_virtual_network_id>"

peering_name_prefix = "online-banking-np1"

private_dns_zone_resource_group_name = "<platform-connectivity output: resource_group_name>"

private_dns_zones = {
  app_service   = { name = "privatelink.azurewebsites.net" }
  key_vault     = { name = "privatelink.vaultcore.azure.net" }
  storage_blob  = { name = "privatelink.blob.core.windows.net" }
  storage_queue = { name = "privatelink.queue.core.windows.net" }
  storage_file  = { name = "privatelink.file.core.windows.net" }
}
```

For initial smoke tests, leave gateway transit disabled:

```hcl
hub_to_spoke = {
  allow_forwarded_traffic = true
  allow_gateway_transit   = false
  use_remote_gateways     = false
}

spoke_to_hub = {
  allow_forwarded_traffic = true
  allow_gateway_transit   = false
  use_remote_gateways     = false
}
```

After ExpressRoute or VPN gateway is deployed in the hub, set `hub_to_spoke.allow_gateway_transit = true` and `spoke_to_hub.use_remote_gateways = true` for spokes that should use the hub gateway.

## Permissions

The HCP run identity needs network permissions in both subscriptions:

- `Network Contributor` on the hub VNet or hub network resource group.
- `Network Contributor` on the spoke VNet or spoke network resource group.
- `Private DNS Zone Contributor` on the hub Private DNS zone resource group.

The Azure dynamic credential or federated credential must cover this workspace for both plan and apply phases.

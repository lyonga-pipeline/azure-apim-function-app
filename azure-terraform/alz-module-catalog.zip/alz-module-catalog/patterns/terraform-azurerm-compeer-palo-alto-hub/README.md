# terraform-azurerm-compeer-palo-alto-hub

> **⚠ Before the first real apply of `platform-palo-alto`:** both firewalls'
> `admin_ssh_keys` in the real `terraform.tfvars` are still the literal
> placeholder string `"ssh-ed25519 AAAA... replace"` — deliberately left as a
> placeholder, not a real key, since generating one isn't something to do on
> the network team's behalf. Swap in the real public key(s) the network team
> will use to manage `vm-fw-hub-01` / `vm-fw-hub-02` before applying — the
> mock-provider test suite doesn't catch this because it uses its own
> throwaway key. Confirmed `terraform validate` doesn't catch it either
> (verified against the real workspace) — the string is a syntactically
> plausible key with no format `validation` block checking it, so it passes
> until a real `plan`/`apply` reaches the actual Azure API.

**Pattern module.** Deploys the Azure side of a Palo Alto VM-Series firewall hub
**entirely in Terraform** - no Marketplace *solution template*. Terraform owns
every VM, NIC, load balancer, public IP, and the bootstrap artifacts, so the
deployment matches Compeer's requirements (2 firewalls, an extra internal load
balancer + NICs for Sunstream, private-only edge) instead of the fixed
Marketplace shape.

## Marketplace vs. image-based - the distinction

| | Marketplace solution template | This pattern (image-based) |
|---|---|---|
| What deploys | Microsoft-authored template: 2 VMs + 1 internal LB, fixed | Whatever you declare in tfvars |
| VM plan/agreement | Accepted by the template | `azurerm_marketplace_agreement` (still required - it is the **image licence**, not the template) |
| Extra NICs / 2nd LB (Sunstream) | Not possible | Add map entries |
| Custom routing, identities, tags | Bolt-ons afterward | Native |

Set `marketplace_agreement.enabled = true` **once per subscription** to accept
the `paloaltonetworks / vmseries-flex / <plan>` image agreement. That is not
"using Marketplace" in the solution-template sense.

**Licensing decision: PAYG, plan `bundle2`** (this pattern's own default for
both `marketplace_agreement.plan` and `virtual_machines[*].source_image_reference` /
`.plan` — no override needed). `bundle2` is a pay-as-you-go (hourly) Azure
Marketplace plan, not BYOL: NGFW + Threat Prevention + DNS Security +
WildFire + URL Filtering (PAN-DB) + GlobalProtect + Premium Support, vs.
`bundle1`'s NGFW + Threat Prevention + Premium Support only. Verify current
entitlements against the live Azure Marketplace listing before go-live —
bundle contents are Palo Alto's to change, not something this repo controls.

## Overview

**What this deploys:** a fully Terraform-owned (no Marketplace solution
template) Palo Alto VM-Series firewall hub — every VM, NIC, load balancer,
and public IP, so the shape matches Compeer's actual requirements instead of
the Marketplace template's fixed 2-VM/1-LB layout.

## What it composes

| Concern | Resource / module | Notes |
|---|---|---|
| Bootstrap storage | `storage-account` module + `azurerm_storage_share` | `public_network_access_enabled = false` by default |
| Bootstrap layout | `azurerm_storage_share_directory` / `_file` | `config` / `content` / `license` / `software` + `init-cfg.txt` |

**`azurerm_storage_share` vs `_share_directory` vs `_share_file` — not
redundant, three different levels of the same hierarchy:** the *share*
(`azurerm_storage_share.bootstrap`) is the file-share container itself; the
*directories* (`azurerm_storage_share_directory.bootstrap`) are the
`config`/`content`/`license`/`software` folders inside it; the *files*
(`azurerm_storage_share_file.bootstrap`, e.g. `init-cfg.txt`) are the actual
content uploaded into those folders. All three are required — removing any
one breaks the bootstrap (no share to put folders in, no folders to
organize files in, or no actual config content for the firewall to read).
| Public IPs | `public-ip` module | mgmt + untrust only; pin their RG in the private-only allow-list |
| NICs | `network-interface` module | `ip_forwarding_enabled = true`; 3 per firewall + any Sunstream NICs |
| Load balancers | `load-balancer` module | `trust` ILB + `sunstream` ILB (just another map key) |
| Firewall VMs | `azurerm_linux_virtual_machine.vm` (for_each) | Custom, image-based: `source_image_reference` + `plan`; system-assigned identity, `custom_data` bootstrap. **This is the only VM path** — the `PaloAltoNetworks/swfw-modules` AVM module was removed. |
| Firewall backup | `recovery-services-vault` module + `azurerm_backup_protected_vm.firewall` | Optional connectivity-subscription RSV and VM backup enrolment for firewall VMs |

## Bootstrap (`virtual_machines[*].bootstrap`)

| `mode` | Needs | `custom_data` becomes | State impact |
|---|---|---|---|
| `none` (default) | - | unset | - |
| `azure-file-share` (own storage) | nothing — set `var.bootstrap_storage_account`; key read from a data source | `storage-account=…\naccess-key=…\nfile-share=…\nshare-directory=…` (base64) | **key in state** |
| `azure-file-share` (external storage) | BOTH `storage_account_name` + `storage_account_key` (e.g. phase-1 output) | same | **key in state** |
| `custom-data` | `custom_data` or `init_cfg_content` | your text (base64) | none |

`bootstrap_share_layout` lays down the PAN-OS folder structure and can upload an
`init-cfg.txt` / `bootstrap.xml` from a local path or inline `content`. VMs
`depend_on` the uploaded files, so within one apply the config lands before the
firewall boots.

For a key-free flow, use `mode = "custom-data"` with a PAN-OS 10+ `init-cfg.txt`
(`type=dhcp-client`, `plugin-op-commands=set-cores:<n>`, `vm-auth-key`,
`panorama-server` / `tplname` / `dgname`) and let the firewall pull config from
Panorama / Strata Cloud Manager.

### Two-phase deployment

If bootstrap storage is provisioned by a **separate phase-1 workspace** (e.g.
`azure-fw-bootstrap/`), point each firewall at it: `bootstrap.mode =
"azure-file-share"` + `storage_account_name` from the phase-1 output, and pass
the key via the workspace's `palo_alto_bootstrap_storage_keys` map (sensitive).
Leave `var.bootstrap_storage_account = null` so this pattern doesn't create a
second one.

## Sunstream

Sunstream needs a second internal load balancer and additional dataplane
interfaces. Both are plain map entries - no module change: add
`fwN_sunstream` keys to `network_interfaces`, a `sunstream` key to
`load_balancers`, and the extra NIC keys to each firewall's
`network_interface_keys`.

## Lifecycle contract

| Change | Effect |
|---|---|
| Add a `virtual_machines` / `network_interfaces` / `load_balancers` key | Creates just that instance (stable `for_each` keys). |
| `virtual_machines[*].size` | In-place resize (VM restart). |
| `virtual_machines[*].bootstrap`, `custom_data`, `source_image_reference` | **Replace** the VM (`custom_data` is ForceNew). Plan a firewall-by-firewall window. |
| `network_interface_keys` order/content | Replace the VM. |
| `bootstrap_share_layout` files | In-place upload; does not touch VMs. |

## State exposure

`bootstrap.storage_account_key` (file-share mode) and `admin_password` are stored
in Terraform state. Prefer `custom-data` mode + SSH keys. Outputs:
`virtual_machine_ids`, `virtual_machine_identity_principal_ids`,
`network_interface_ids`, `load_balancer_ids`, `public_ip_ids`,
`bootstrap_storage_account_id`, `bootstrap_storage_share_ids`,
`marketplace_agreement_id`, `recovery_services_vault_ids`,
`backup_policy_vm_ids`, and `firewall_backup_protected_vm_ids`.

## Migration

**Breaking:** the `PaloAltoNetworks/swfw-modules//modules/vmseries` AVM module
path was **removed**. `var.vendor_vmseries`, `var.vendor_vmseries_passwords`, and
the `vendor_vmseries` output are gone; the workspace's
`palo_alto_vendor_vmseries_passwords` is replaced by
`palo_alto_bootstrap_storage_keys`. All firewalls now use the custom,
image-based `azurerm_linux_virtual_machine` path. If you had `vendor_vmseries`
entries, re-express them as `virtual_machines` + `network_interfaces` +
`load_balancers` map entries (the pattern already had this path).

Additive: `virtual_machines[*].bootstrap` (incl. self-service key from the
pattern's own bootstrap storage), `virtual_machines[*].identity`,
`bootstrap_share_layout`, the `azurerm_storage_share_directory` / `_file`
resources, the `local` provider. `azurerm_storage_share` switched from the
deprecated `storage_account_name` to `storage_account_id`.

Panorama / Strata Cloud Manager policy onboarding stays a separate operational
contract. Keep the workspace disabled until firewall licensing, image plan
acceptance, the bootstrap process, and routing ownership are approved.

## Tests

`terraform test` - 2 firewalls / 2 LBs / 6 NICs, both bootstrap modes rendered,
the four bootstrap directories, firewall backup enrolment, and the
file-share-without-key rejection.

## Bootstrap storage / Key Vault network posture

The firewalls reach bootstrap storage over SMB from the mgmt NIC, and Key Vault
for cert auth via managed identity. Both stay **private**:

- `bootstrap_storage_account.network_rules` &mdash; `default_action = "Deny"` +
  `allowed_subnet_keys = ["palo_alto_management"]` (a **service endpoint**, not a
  public endpoint). `public_network_access_enabled = true` is only the
  service-endpoint requirement; the account is firewalled to that one subnet.
- `bootstrap_key_vault` &mdash; `network.mode = "private"` + a `private_endpoint`
  block. The firewall VM identities get `Key Vault Certificates User` +
  `Secrets User` automatically.

If a genuine public path is unavoidable, `network.mode = "selected"` (KV) or a
non-empty `network_rules` (storage) &mdash; the modules then **require** a Deny +
IP/subnet allow-list. Pair it with a policy carve-out / exemption. See
[`GUARDRAIL-EXCEPTIONS.md`](../../GUARDRAIL-EXCEPTIONS.md).

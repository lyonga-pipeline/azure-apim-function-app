variable "subscription_id" {
  type        = string
  description = "Platform identity subscription id."
}

variable "tenant_id" {
  type        = string
  description = "Azure tenant id. Leave null to use the tenant from the active Azure credentials."
  default     = null
}

variable "location" {
  type        = string
  description = "Azure region for identity resources."
}

variable "environment" {
  type        = string
  description = "Environment key, such as np or prod."
}

variable "naming" {
  description = "Root identity for the naming module. Component 'identity'; only region + environment needed. A `name` on a resource block still wins. The Key Vault name now leads with the component's own abbreviation (e.g. \"id-cus-prod-vault\"), not a hardcoded workload-style appcode of \"platform\"."
  type = object({
    region               = optional(string)
    environment          = optional(string)
    scope                = optional(string, "platform")
    component            = optional(string, "identity")
    domain               = optional(string)
    appcode              = optional(string)
    abbreviation         = optional(string)
    key_vault_name_token = optional(string, "vault")
    storage_uniqueness   = optional(string, "")
  })
  default = {}
}


variable "platform_tags" {
  type = object({
    application           = optional(string)
    appcode               = optional(string)
    owner                 = optional(string)
    source_repo           = optional(string)
    created_on            = optional(string)
    criticality_tier      = optional(string)
    data_classification   = optional(string)
    lifecycle_state       = optional(string)
    cost_center           = optional(string)
    gl_category           = optional(string)
    application_component = optional(string)
    modified_on           = optional(string)
    created_by            = optional(string)
    dr_tier               = optional(string)
    expiration_date       = optional(string)
    time_bound_exception  = optional(bool, false)
    additional_tags       = optional(map(string), {})
  })
  default = {}
}

variable "resource_group" {
  type = object({
    name = optional(string)
  })
}

variable "platform_identities" {
  type = map(object({
    name = optional(string)
  }))
  default = {}
}

variable "key_vault" {
  type = object({
    name                            = optional(string)
    sku_name                        = optional(string, "standard")
    soft_delete_retention_days      = optional(number, 90)
    purge_protection_enabled        = optional(bool, true)
    rbac_authorization_enabled      = optional(bool, true)
    enabled_for_deployment          = optional(bool, false)
    enabled_for_disk_encryption     = optional(bool, false)
    enabled_for_template_deployment = optional(bool, false)
    public_network_access_enabled   = optional(bool, false)
    access_policies = optional(list(object({
      tenant_id               = string
      object_id               = string
      application_id          = optional(string)
      key_permissions         = optional(list(string), [])
      secret_permissions      = optional(list(string), [])
      certificate_permissions = optional(list(string))
      storage_permissions     = optional(list(string))
    })), [])
    access_policies_by_key = optional(map(object({
      tenant_id               = string
      object_id               = string
      application_id          = optional(string)
      key_permissions         = optional(list(string), [])
      secret_permissions      = optional(list(string), [])
      certificate_permissions = optional(list(string), [])
      storage_permissions     = optional(list(string), [])
    })), {})
    network_acls = optional(object({
      default_action             = string
      bypass                     = string
      ip_rules                   = optional(list(string))
      virtual_network_subnet_ids = optional(list(string))
    }))
    contacts = optional(map(object({
      email = string
      name  = optional(string)
      phone = optional(string)
    })), {})
    timeouts = optional(object({
      create = optional(string)
      update = optional(string)
      read   = optional(string)
      delete = optional(string)
    }), {})
  })
}

variable "identity_role_assignments" {
  type = map(object({
    name                                   = optional(string)
    identity_key                           = string
    scope                                  = optional(string)
    role_definition_name                   = optional(string)
    role_definition_id                     = optional(string)
    principal_type                         = optional(string, "ServicePrincipal")
    description                            = optional(string)
    condition                              = optional(string)
    condition_version                      = optional(string)
    skip_service_principal_aad_check       = optional(bool)
    delegated_managed_identity_resource_id = optional(string)
  }))
  default = {}
}

variable "external_role_assignments" {
  type = map(object({
    name                                   = optional(string)
    scope                                  = string
    principal_id                           = string
    role_definition_name                   = optional(string)
    role_definition_id                     = optional(string)
    principal_type                         = optional(string)
    description                            = optional(string)
    condition                              = optional(string)
    condition_version                      = optional(string)
    skip_service_principal_aad_check       = optional(bool)
    delegated_managed_identity_resource_id = optional(string)
  }))
  default = {}
}

variable "log_analytics_workspace_id" {
  type        = string
  description = "Shared Log Analytics workspace ID for diagnostics. Leave null to skip Key Vault diagnostics until platform-management is available."
  default     = null
}

variable "diagnostics" {
  type = object({
    log_analytics_destination_type = optional(string)
    logs = optional(map(object({
      category       = optional(string)
      category_group = optional(string)
      })), {
      all_logs = {
        category_group = "allLogs"
      }
    })
    metrics = optional(map(object({
      category = string
      enabled  = optional(bool, true)
      })), {
      all_metrics = {
        category = "AllMetrics"
        enabled  = true
      }
    })
  })
  default = {}
}

variable "additional_lock_scopes" {
  type        = map(string)
  description = "Additional named scopes that can be referenced by management_locks."
  default     = {}
}

variable "disk_encryption_sets" {
  description = <<-EOT
    Customer-managed-key disk encryption sets — design doc Phase 5 Step 6
    ("Compute and Disk Encryption Controls"). Required for regulated-apps-mg /
    Restricted-data workloads; optional elsewhere. key_vault_key_id should
    reference a key created in this pattern's key_vault (see
    terraform-azurerm-compeer-key-vault-key in the composition root). Use a
    versionless Key Vault key ID when auto_key_rotation_enabled is true.
    After creation, grant each DES's identity_principal_id "Key Vault Crypto
    Service Encryption User" on the source key via identity_role_assignments
    or external_role_assignments, then pass the output id to a VM pattern's
    os_disk.disk_encryption_set_id.
  EOT
  type = map(object({
    name                      = string
    key_vault_key_id          = optional(string)
    managed_hsm_key_id        = optional(string)
    encryption_type           = optional(string, "EncryptionAtRestWithCustomerKey")
    auto_key_rotation_enabled = optional(bool, true)
    identity_type             = optional(string, "SystemAssigned")
    identity_ids              = optional(list(string))
  }))
  default = {}
}

variable "management_locks" {
  type = map(object({
    name       = string
    scope_key  = optional(string)
    scope      = optional(string)
    lock_level = optional(string, "CanNotDelete")
    notes      = optional(string)
  }))
  description = "Locks for critical platform identity resources."
  default     = {}

  validation {
    condition = alltrue([
      for item in values(var.management_locks) :
      (
        (try(item.scope, null) != null || try(item.scope_key, null) != null) &&
        !(try(item.scope, null) != null && try(item.scope_key, null) != null)
      )
    ])
    error_message = "Each management lock must set exactly one of scope or scope_key."
  }
}

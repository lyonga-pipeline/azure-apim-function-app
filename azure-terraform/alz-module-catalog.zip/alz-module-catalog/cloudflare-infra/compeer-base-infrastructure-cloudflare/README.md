# Overview
Base infrastructure for the Cloudflare tunnel VMs.
VMs created in https://dev.azure.com/Compeer-financial-cloud/InfrastructureAutomation/_git/compeer-cloudflare-tunnels

# Prerequisites

This Terraform configuration requires several pre-existing Azure resources across multiple subscriptions. These resources must exist before deployment.

## Hub Network Subscription

| Resource Type | Resource Name | Purpose | Used By |
|---------------|---------------|---------|---------|
| Virtual Network | `ncus-hub-10.100.184.0` | Hub network for spoke-to-hub peering and routing | vnet |
| Resource Group | `net-ncus-hub-rg` | Contains the hub virtual network | vnet |


## Current Subscription

| Resource Type | Resource Name | Purpose | Used By |
|---------------|---------------|---------|---------|
| Resource Group | `{application_code}-{region}-{environment}-rg` | Contains virtual network and associated resources (when `create_resource_group = false`) | vnet |
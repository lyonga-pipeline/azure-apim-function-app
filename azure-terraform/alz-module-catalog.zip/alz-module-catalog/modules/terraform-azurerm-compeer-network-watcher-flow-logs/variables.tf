variable "flow_logs" {
  description = "Network Watcher flow logs keyed by logical name."
  type = map(object({
    name                      = string
    network_watcher_name      = string
    resource_group_name       = string
    network_security_group_id = string
    storage_account_id        = string
    enabled                   = optional(bool, true)
    retention_policy = optional(object({
      enabled = optional(bool, true)
      days    = optional(number, 90)
    }), {})
    traffic_analytics = optional(object({
      enabled               = optional(bool, true)
      workspace_id          = string
      workspace_region      = string
      workspace_resource_id = string
      interval_in_minutes   = optional(number, 10)
    }))
    timeouts = optional(object({
      create = optional(string)
      read   = optional(string)
      update = optional(string)
      delete = optional(string)
    }), {})
  }))
  default = {}
}

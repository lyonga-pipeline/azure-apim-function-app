# terraform-azurerm-compeer-data-lake

A single ADLS Gen2 filesystem in a caller-owned HNS-enabled storage account. The storage account, ACL paths and RBAC are owned elsewhere.

## Contract

- Resource: `azurerm_storage_data_lake_gen2_filesystem` (ADLS Gen2 filesystem).
- Inputs are explicitly typed; optional blocks are `optional(object(...))` and repeatables are `map(object(...))` keyed by a caller-stable name.
- Adjacent resource-group / network / RBAC / diagnostic capabilities are composed externally.

## Lifecycle

| Change | Effect |
|---|---|
| `properties`, `ace` (path ACLs) | In-place update |
| `data_lake_gen2_fs_name`, `storage_account_id` | Replace |

## State exposure

Outputs: `data_lake_gen2_fs_id`. No secrets.

## Migration

No breaking changes. An unused `azurerm_client_config` data lookup was removed; dependencies are passed explicitly.

## Tests

`terraform test` (`tests/defaults.tftest.hcl`, `mock_provider`) — create and attribute wiring; validation failures where the module adds `validation` / `precondition` rules.

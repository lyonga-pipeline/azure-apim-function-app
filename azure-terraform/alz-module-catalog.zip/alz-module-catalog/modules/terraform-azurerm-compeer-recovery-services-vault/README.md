# terraform-azurerm-compeer-recovery-services-vault

A single azurerm_recovery_services_vault. Backup/site-recovery policies and protected items are separate resources.

## Contract

Inputs are explicitly typed; repeatable configuration uses `map(object)` with
caller-stable keys. See `variables.tf` for the full surface and `outputs.tf`
for composition-ready IDs/attributes.

## Lifecycle

Configuration changes update in place unless the Azure resource marks the field
ForceNew (name / location / scope / parent). Adding or removing a map key affects
only that entry. Durable/state-bearing resources (workspaces, vaults, budgets,
management groups) must not be recreated by routine module upgrades.

State exposure: only where a secret input or sensitive output is documented in
`variables.tf` / `outputs.tf`.

## Migration

versions.tf standardised; descriptions and value validation added; `x == null || x.attr`
validation patterns fixed.

**Removed `soft_delete_enabled`** - deprecated by the AzureRM provider and removed
in v5.0 (soft delete is always on under Azure's secure-by-default policy). Drop
the argument from any caller; behaviour is unchanged.

## Tests

`terraform test` (offline, `mock_provider`): create / no-op, and key
validations & preconditions where present.

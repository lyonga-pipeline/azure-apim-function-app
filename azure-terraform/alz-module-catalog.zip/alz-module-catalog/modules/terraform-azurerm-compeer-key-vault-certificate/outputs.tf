output "ids" {
  description = "Map of caller-supplied key to certificate resource ID."
  value       = { for key, value in azurerm_key_vault_certificate.certificate : key => value.id }
}

# terraform-azurerm-compeer-container-instance

An Azure Container Instances **container group** (`azurerm_container_group`).
The resource group, subnet, image registry credentials and log workspace are
caller-owned.

## Contract

- Required: `container_name`, `resource_group_name`, `location`,
  `container_info` (at least one entry).
- `container_info` is a `map(object)` keyed by a caller-stable name; each entry
  has `name`, `image`, `cpu`, `memory`, optional `environment_variables`,
  `secure_environment_variables`, `ports` (keyed `map(object)`).
- `os_type` (`Linux` / `Windows`) and `ip_address_type`
  (`Public` / `Private` / `None`) are validated.
- `subnet_ids` defaults to `[]` and is used only for `ip_address_type = Private`.
- `dns_config` defaults to `{}` (only the first entry is applied — the provider
  block is singular).

## Lifecycle

| Change | Effect |
|---|---|
| any `container_info` / `dns_config` / `tags` change | Replace (ACI container groups are immutable) |
| `subnet_ids`, `ip_address_type`, `os_type`, name, location | Replace |

## State exposure

`secure_environment_variables` values are stored in Terraform state. Outputs:
`id`, `name`, `ip_address`, `fqdn`.

## Migration

`subnet_ids` and `dns_config` are now optional (default `[]` / `{}`), so a
public container group no longer needs dummy values. `tags` input added and
wired. `container_info` now requires at least one entry (validation).

## Tests

`terraform test` — create (public), and empty-`container_info` rejection.

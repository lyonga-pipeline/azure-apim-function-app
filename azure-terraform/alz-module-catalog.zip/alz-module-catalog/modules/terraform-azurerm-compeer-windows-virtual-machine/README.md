# terraform-azurerm-compeer-windows-virtual-machine

Lean single Windows VM (`azurerm_windows_virtual_machine`). NICs, managed data
disks, extensions and domain-join are caller-owned. Identical contract and
lifecycle to `terraform-azurerm-compeer-windows-vm` — see that module's README
for the full input / output / lifecycle detail. Prefer `windows-vm` for new work;
both are maintained to the same standard.

## Outputs

`id`, `name`, `identity`, `identity_principal_id`, `private_ip_addresses`.

## Migration

Breaking renames (0 consumers, no shims): `virtual_machine_name`→`name`,
`resource_group_location`→`location`, `virtual_machine_size`→`vm_size`,
`availability_zone`→`zone`; `output.virtual_machine_id`→`id`,
`output.virtual_machine_name`→`name`.

Removed: placeholder `availability-set.tf` / `managed-disks.tf` /
`network-interface.tf` / `vm_extension.tf` files, `data.tf`, `go.mod` / `go.sum`,
the `templates/` dir (`formatDisk.ps1.tpl` — belonged with a data-disk extension
that no longer exists here) and the Terratest `test/` dir. Precondition
null-deref on `var.identity` fixed. `enable_automatic_updates` →
`automatic_updates_enabled`. Input descriptions added.

## Tests

`terraform test` (offline): Trusted-Launch defaults, zone/availability-set
exclusivity, weak-password rejection.
